<div class="<?php echo $this->text_domain ?> how-to-use"> 
    <h1>How to use </h1>

    <div class="how-to-group"> 
        <div class="title"> With Custom posts</div>
        <div>
            If you   want to use custom post, you can easily use as copy short code from our custom list. or you can use it following : <br/>
            <pre>
                [wpob-popover   id='YourCustomPostID'] 

                for example :  
                [wpob-popover id='99'] 
            </pre>
        </div>
    </div>
 
    
    <div class="how-to-group"> 
        <div class="title"> Set custom style</div>
        <div>
             If you want to change style of popover, you can set custom background color, text color, popover position, width and more for plugin settings page.  
        </div>
    </div>
    
     
    <div class="how-to-group"> 
        <div class="title"> Set height-width for popover</div>
        <div>
             Set 'auto' for popover height and width in settings. 
        </div>
    </div>
    
     
    
    
</div>